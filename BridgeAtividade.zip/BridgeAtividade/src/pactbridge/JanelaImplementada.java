package pactbridge;

/**
 *
 * @author lais, artur, joão marcos
 */

public interface JanelaImplementada {

	void desenharJanela(String titulo);

	void desenharBotao(String titulo);
}